# Release Notes

## Version 1.0.0
- Initial release
- Added calculator in the Odoo systray
- Lightweight and fast user interface
- No configuration required
