# -*- coding: utf-8 -*-
# (c) 2025 Woocket
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl).
